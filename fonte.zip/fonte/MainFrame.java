import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame {

    private JTextField entrada;
    private JTextArea saida;

    private LL1Parser parser;
    private SentenceGenerator generator;

    public MainFrame() {

        parser = new LL1Parser();
        generator = new SentenceGenerator();

        setTitle("Analisador Sintático LL(1)");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        entrada = new JTextField(30);

        saida = new JTextArea();
        saida.setEditable(false);

        JScrollPane scroll = new JScrollPane(saida);

        JButton btnGramatica = new JButton("Mostrar Gramática");

        JButton btnFirstFollow = new JButton("FIRST / FOLLOW");

        JButton btnTabela = new JButton("Tabela Parsing");

        JButton btnGerar = new JButton("Gerar Sentença");

        JButton btnAnalisar = new JButton("Analisar");

        JButton btnLimpar = new JButton("Reiniciar");

        JPanel painelTopo = new JPanel();

        painelTopo.add(btnGramatica);
        painelTopo.add(btnFirstFollow);
        painelTopo.add(btnTabela);

        JPanel painelEntrada = new JPanel();

        painelEntrada.add(new JLabel("Sentença:"));

        painelEntrada.add(entrada);

        painelEntrada.add(btnGerar);
        painelEntrada.add(btnAnalisar);
        painelEntrada.add(btnLimpar);

        setLayout(new BorderLayout());

        add(painelTopo, BorderLayout.NORTH);

        add(scroll, BorderLayout.CENTER);

        add(painelEntrada, BorderLayout.SOUTH);
        btnGramatica.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                String texto = "GRAMÁTICA\n\n";

                texto += "P -> S\n";
                texto += "S -> iA | lB | ε\n";
                texto += "A -> pA | q\n";
                texto += "B -> rB | t\n";

                saida.setText(texto);
            }
        });
        btnFirstFollow.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                StringBuilder sb = new StringBuilder();

                sb.append("FIRST\n\n");

                for (String nt : LL1Data.FIRST.keySet()) {

                    sb.append("FIRST(");
// monta conjunto pra exibir, essa e nas outras
                    sb.append(nt);

                    sb.append(") = ");

                    sb.append(LL1Data.FIRST.get(nt));

                    sb.append("\n");
                }

                sb.append("\nFOLLOW\n\n");

                for (String nt : LL1Data.FOLLOW.keySet()) {

                    sb.append("FOLLOW(");

                    sb.append(nt);

                    sb.append(") = ");

                    sb.append(LL1Data.FOLLOW.get(nt));

                    sb.append("\n");
                }

                saida.setText(sb.toString());
            }
        });

        // formatar dps, ta em linha

        btnTabela.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                StringBuilder sb = new StringBuilder();

                sb.append("TABELA DE PARSING LL(1)\n\n");

                sb.append(String.format("%-8s%-15s%-15s%-15s%-15s%-15s%-15s%-15s\n", "NT", "i", "l", "p", "q", "r", "t", "$"));

                sb.append("-----------------------------------------------------------------------------------------------\n");

                String[] nts = {"P", "S", "A", "B"};

                String[] terms = {"i", "l", "p", "q", "r", "t", "$"};

                for (String nt : nts) {

                    sb.append(String.format("%-8s", nt));

                    for (String t : terms) {

                        java.util.List<String> prod = LL1Data.TABELA.get(nt + "|" + t);

                        String celula = "-";

                        if (prod != null) {

                            celula = nt + " → " + juntar(prod);
                        }
                        sb.append(String.format("%-15s", celula));
                    }
                    sb.append("\n");
                }
                saida.setText(sb.toString());
            }
        });

        btnGerar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                entrada.setText(generator.gerar());
            }
        });

        btnAnalisar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                LL1Parser.Resultado r = parser.analisar(entrada.getText().trim());

                String texto = r.getLog();

                texto += "\n\nRESULTADO FINAL\n\n";

                if (r.isAceita()) {

                    texto += "Sentença aceita em " + r.getPassos() + " passos.";

                } else {

                    texto += "Sentença rejeitada em " + r.getPassos() + " passos.";
                }

                saida.setText(texto);
            }
        });

        btnLimpar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                entrada.setText("");

                saida.setText("");
            }
        });
    }

    private String juntar(java.util.List<String> lista) {

        StringBuilder sb = new StringBuilder();

        for (String s : lista) {

            sb.append(s).append(" ");
        }

        return sb.toString().trim();
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                new MainFrame().setVisible(true);
            }
        });
    }
}
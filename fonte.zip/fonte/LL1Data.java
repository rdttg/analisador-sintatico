import java.util.*;

public class LL1Data {

    public static final String EPSILON = "ε";
    public static final String FIM = "$";

    public static final Map<String, List<List<String>>> GRAMATICA = new HashMap<String, List<List<String>>>();

    public static final Map<String, Set<String>> FIRST = new HashMap<String, Set<String>>();

    public static final Map<String, Set<String>> FOLLOW = new HashMap<String, Set<String>>();

    public static final Map<String, List<String>> TABELA = new HashMap<String, List<String>>();

    static {

        GRAMATICA.put("P", Arrays.asList(Arrays.asList("S")));

        GRAMATICA.put("S", Arrays.asList(Arrays.asList("i", "A"), Arrays.asList("l", "B"), Arrays.asList(EPSILON)));

        GRAMATICA.put("A", Arrays.asList(Arrays.asList("p", "A"), Arrays.asList("q")));

        GRAMATICA.put("B", Arrays.asList(Arrays.asList("r", "B"), Arrays.asList("t")));

        FIRST.put("P", new HashSet<String>(Arrays.asList("i", "l", EPSILON)));

        FIRST.put("S", new HashSet<String>(Arrays.asList("i", "l", EPSILON)));
        // esta substfdituindo, revisar

        FIRST.put("A", new HashSet<String>(Arrays.asList("p", "q")));

        FIRST.put("B", new HashSet<String>(Arrays.asList("r", "t")));

        FOLLOW.put("P", new HashSet<String>(Arrays.asList(FIM)));

        FOLLOW.put("S", new HashSet<String>(Arrays.asList(FIM)));

        FOLLOW.put("A", new HashSet<String>(Arrays.asList(FIM)));

        FOLLOW.put("B", new HashSet<String>(Arrays.asList(FIM)));

        put("P", "i", "S");
        put("P", "l", "S");
        put("P", "$", "S");

        put("S", "i", "i", "A");
        put("S", "l", "l", "B");
        put("S", "$", EPSILON);

        put("A", "p", "p", "A");
        put("A", "q", "q");

        put("B", "r", "r", "B");
        put("B", "t", "t");
    }

    private static void put(String nt, String terminal, String... producao) {

        TABELA.put(nt + "|" + terminal, Arrays.asList(producao));
    }
}
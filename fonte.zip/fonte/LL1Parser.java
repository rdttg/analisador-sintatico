import java.util.*;

public class LL1Parser {

    public static class Resultado {

        private boolean aceita;
        private String log;
        private int passos;

        public Resultado(boolean aceita, String log, int passos) {

            this.aceita = aceita;
            this.log = log;
            this.passos = passos;
        }

        public boolean isAceita() {
            return aceita;
        }

        public String getLog() {
            return log;
        }

        public int getPassos() {
            return passos;
        }
    }

    public Resultado analisar(String entradaTexto) {

        List<String> entrada = new ArrayList<String>();

        if (!entradaTexto.trim().isEmpty() && !entradaTexto.equals("ε")) {

            for (char c : entradaTexto.toCharArray()) {

                entrada.add(String.valueOf(c));
            }
        }

        entrada.add(LL1Data.FIM);

        Stack<String> pilha = new Stack<String>();

        pilha.push(LL1Data.FIM);

        pilha.push("P");

        int ponteiro = 0;

        int contador = 0;

        StringBuilder log = new StringBuilder();

        log.append(String.format("%-8s %-25s %-25s %s\n", "PASSO", "PILHA", "ENTRADA", "AÇÃO"));

        log.append("---------------------------------------------------------------------------------\n"); // persing

        while (!pilha.isEmpty()) {

            contador++;

            String topo = pilha.peek();

            String token = entrada.get(ponteiro);

            String pilhaTxt = juntarPilha(pilha);

            // String pilhaSe = juntarPilha(pilha);

            String entradaTxt = juntarEntrada(entrada, ponteiro);

            if (topo.equals(token) && topo.equals(LL1Data.FIM)) {

                log.append(linha(contador, pilhaTxt, entradaTxt, "ACEITA"));

                return new Resultado(true, log.toString(), contador);
            }

            if (ehTerminal(topo) || topo.equals(LL1Data.FIM)) {

                if (topo.equals(token)) {

                    log.append(linha(contador, pilhaTxt, entradaTxt, "LER '" + token + "'"));

                    pilha.pop();
                    ponteiro++;

                    continue;
                }

                log.append(linha(contador, pilhaTxt, entradaTxt, "ERRO"));

                return new Resultado(false, log.toString(), contador);
            }

            List<String> producao = LL1Data.TABELA.get(topo + "|" + token);

            if (producao == null) {

                log.append(linha(contador, pilhaTxt, entradaTxt, "ERRO"));

                return new Resultado(false, log.toString(), contador);
            }

            pilha.pop();

            if (!producao.get(0).equals(LL1Data.EPSILON)) {

                for (int i = producao.size() - 1; i >= 0; i--) {

                    pilha.push(producao.get(i));
                }
            }

            log.append(linha(contador, pilhaTxt, entradaTxt, topo + " -> " + juntarProducao(producao)));
        }

        return new Resultado(false, log.toString(), contador);
    }

    private boolean ehTerminal(String simbolo) {

        return simbolo.equals("i") || simbolo.equals("l") || simbolo.equals("p") || simbolo.equals("q") || simbolo.equals("r") || simbolo.equals("t");
    }

    private String juntarPilha(Stack<String> pilha) {

        StringBuilder sb = new StringBuilder(); // sd zera se pilha s

        for (String s : pilha) {
            sb.append(s).append(" ");
        }

        return sb.toString();
    }

    private String juntarEntrada(List<String> entrada, int pos) {

        StringBuilder sb = new StringBuilder();

        for (int i = pos; i < entrada.size(); i++) {

            sb.append(entrada.get(i)).append(" ");
        }

        return sb.toString();
    }

    private String juntarProducao(List<String> prod) {

        StringBuilder sb = new StringBuilder();

        for (String s : prod) {

            sb.append(s).append(" ");
        }

        return sb.toString().trim();
    }

    private String linha(int passo, String pilha, String entrada, String acao) {

        return String.format("%-8d %-25s %-25s %s\n", passo, pilha, entrada, acao);
    }
}
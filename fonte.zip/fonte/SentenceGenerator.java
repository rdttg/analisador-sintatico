import java.util.*;

public class SentenceGenerator {

    private Random random = new Random();

    public String gerar() {

        List<String> resultado = expandir("P", 0);

        if (resultado.isEmpty()) {
            return "ε";
        }
        StringBuilder sb = new StringBuilder();
        for (String s : resultado) {
            sb.append(s);
        }
        return sb.toString();
    }

    private List<String> expandir(String simbolo, int profundidade) {

        List<String> resultado = new ArrayList<String>();

        if (ehTerminal(simbolo)) {
            resultado.add(simbolo);
            return resultado;
        }
        if (simbolo.equals(LL1Data.EPSILON)) {

            return resultado;
        }

        List<List<String>> producoes = LL1Data.GRAMATICA.get(simbolo);

        List<String> producao;

        if (profundidade > 6) {
            producao = escolherSemRecursao(simbolo, producoes);

        } else {
            producao = producoes.get(random.nextInt(producoes.size()));
        }
        for (String s : producao) {
            resultado.addAll(expandir(s, profundidade + 1));
        }
        return resultado;
    }

    private List<String> escolherSemRecursao(String simbolo, List<List<String>> producoes) {

        List<List<String>> validas = new ArrayList<List<String>>();

        for (List<String> p : producoes) {
            if (!p.contains(simbolo)) {
                validas.add(p);
            }
        }

        if (validas.isEmpty()) {
            return producoes.get(0);
        }
        return validas.get(random.nextInt(validas.size()));
    }

    private boolean ehTerminal(String s) {

        return s.equals("i") || s.equals("l") || s.equals("p") || s.equals("q") || s.equals("r") || s.equals("t");
    }
}